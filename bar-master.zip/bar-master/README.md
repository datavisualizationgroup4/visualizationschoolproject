# bar     
change the function(d) (return ..... for the ORB, DRB,AST....)for following part                
var barLabel = function(d) { return d['GAME']; };                  
var barValue = function(d) { return parseFloat(d['3P']); };     

csv is testing csv. the relly data is in the "https://github.com/datavisualizationgroup4/visualizationschoolproject/tree/master/nba"          
